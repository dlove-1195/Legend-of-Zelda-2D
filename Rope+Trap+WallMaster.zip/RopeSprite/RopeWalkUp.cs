﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Sprint2
{
    public class RopeWalkUpSprite : ISprite
    {
        public Texture2D Texture;
        private int width;
        private int height;
        private int sourceLocX;
        private int sourceLocY;

        private int delay = 0;
        private int totalDelay = 10;

        private bool movingDown = true;

        public RopeWalkUpSprite(Texture2D texture)
        {
            Texture = texture;
        }


        public RopeWalkUpSprite()
        {
            //another constructor, show nothing
        }
        public void Update()
        {

            width = 15;
            height = 14;
            sourceLocX = 0;
            sourceLocY = 331;

            if (delay >= 5)
            {
                sourceLocY = 300;
                sourceLocX = 1;
                width = 14;
                height = 15;
            }
            delay++;
            if (delay == totalDelay)
            {
                delay = 0;
            }



            if (movingDown)
            {
                Rope.posY--;
                if (Rope.posY <= 0)
                    movingDown = false;
            }
            else
            {
                //doNothing
            }

        }



        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            if (Texture != null)
            {
                Rectangle sourceRectangle = new Rectangle(sourceLocX, sourceLocY, width, height);
                Rectangle destinationRectangle = new Rectangle(Rope.posX, Rope.posY, width * 3, height * 3);

                spriteBatch.Begin();
                spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
                spriteBatch.End();
            }
        }
    }
}