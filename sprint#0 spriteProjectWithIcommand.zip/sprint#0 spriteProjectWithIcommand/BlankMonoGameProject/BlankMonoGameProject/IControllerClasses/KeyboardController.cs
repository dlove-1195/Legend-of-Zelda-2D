﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace SpritesProject
{
    class KeyboardController: IController
    {
		private Dictionary<Keys, ICommand> controllerMappings;
		private Game1 myGame;

		public KeyboardController(Game1 game)
		{
			myGame = game;
			controllerMappings = new Dictionary<Keys, ICommand>();
			controllerMappings.Add(Keys.D0, new QuitCommand(myGame));
			controllerMappings.Add(Keys.D1, new SetNonMovingNonAnimatedSprite(myGame));
			controllerMappings.Add(Keys.D2, new SetNonMovingAnimatedSprite(myGame));
			controllerMappings.Add(Keys.D3, new SetMovingNonAnimatedSprite(myGame));
			controllerMappings.Add(Keys.D4, new SetMovingAnimatedSprite(myGame));

		}

		 
		public void Update()
		{
			Keys[] pressedKeys = Keyboard.GetState().GetPressedKeys();

			foreach (Keys key in pressedKeys)
			{
				controllerMappings[key].Execute();
			}
		}


	}
 }

