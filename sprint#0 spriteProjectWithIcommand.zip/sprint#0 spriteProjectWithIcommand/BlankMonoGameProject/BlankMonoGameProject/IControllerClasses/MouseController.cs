﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace SpritesProject
{
    class MouseController : IController
    {

        private Game1 myGame;



        private enum MouseAction { QuadOne, QuadTwo, QuadThree, QuadFour, RightClick }
       
        private Dictionary<MouseAction, ICommand> controllerMappings;
        public MouseController(Game1 game)
        {
            myGame = game;
            controllerMappings = new Dictionary<MouseAction, ICommand>();
            controllerMappings.Add(MouseAction.RightClick, new QuitCommand(myGame));
            controllerMappings.Add(MouseAction.QuadOne, new SetNonMovingNonAnimatedSprite(myGame));
            controllerMappings.Add(MouseAction.QuadTwo, new SetNonMovingAnimatedSprite(myGame));
            controllerMappings.Add(MouseAction.QuadThree, new SetMovingNonAnimatedSprite(myGame));
            controllerMappings.Add(MouseAction.QuadFour, new SetMovingAnimatedSprite(myGame));
        }

        public void Update()
        {


            int locationX = Mouse.GetState().X;
            int locationY = Mouse.GetState().Y;


            if (Mouse.GetState().RightButton == ButtonState.Pressed)
            {
                
                controllerMappings[MouseAction.RightClick].Execute();

            }
            else if (Mouse.GetState().LeftButton == ButtonState.Pressed)
            {

                if (locationX <= 300 && locationY <= 200)
                    {
                   controllerMappings[MouseAction.QuadOne].Execute();
                   }
                else if (locationX >= 300 && locationY <= 200)
                    {
                    controllerMappings[MouseAction.QuadTwo].Execute();

                 }
                else if (locationX <= 300 && locationY >= 200)
                {
                    
                    controllerMappings[MouseAction.QuadThree].Execute();


                }
                else if (locationX >= 300 && locationY >= 200)
                {
                    controllerMappings[MouseAction.QuadFour].Execute();

                }



            }

        }

    }
}

