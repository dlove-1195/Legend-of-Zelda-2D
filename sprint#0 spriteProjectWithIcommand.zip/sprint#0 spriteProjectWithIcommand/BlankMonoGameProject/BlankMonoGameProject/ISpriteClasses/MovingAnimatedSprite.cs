﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;


namespace SpritesProject
{
    class MovingAnimatedSprite :ISprites 
    {
        public Texture2D Texture { get; set; }
        

        private int width = 16;
        private int height = 32;
        //animated part 
        private int currentFrame = 0;
        private int totalFrames = 5;
        private int delay = 0;
        private int totalDelay = 3;
        //moving part 
        private int xPos = 300;
        private bool movingLeft  = true;

        public MovingAnimatedSprite(Texture2D texture)
        {
            Texture = texture;
        }


        public void Update()
        {
            //animated: the current frame update
            delay++;
            if (delay == totalDelay)
            {
                currentFrame++;
                delay = 0;
            }

            if (currentFrame == totalFrames) { currentFrame = 0; }
            //moving left and right 
            if (movingLeft)
            {
                xPos--;
                if (xPos == 0)
                    movingLeft = false;
            }
            else
            {
                xPos++;
                if (xPos == 600)
                    movingLeft = true;
            }



        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            int currentX = 209 + currentFrame * 26;
            int currentY = 122;
            // moving, animated: source and destination all change
            Rectangle sourceRectangle = new Rectangle( currentX,currentY, width, height);
            Rectangle destinationRectangle = new Rectangle( xPos, (int)location.Y, width, height);
            spriteBatch.Begin();

            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }

}

