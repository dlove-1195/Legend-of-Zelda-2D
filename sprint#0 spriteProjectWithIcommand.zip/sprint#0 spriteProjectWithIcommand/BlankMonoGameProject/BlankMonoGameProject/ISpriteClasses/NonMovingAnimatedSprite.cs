﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace SpritesProject
{
            public class NonMovingAnimatedSprite : ISprites{ 
                public Texture2D Texture { get; set; }
                
                private int currentFrame = 0;
                private int totalFrames = 5;
                private int width = 16 ;
                private int height = 32;
                private int delay=0 ;
                private int totalDelay=3;
               
               
                public NonMovingAnimatedSprite(Texture2D texture)
                {
                    Texture = texture;
                     
                   
                }

                public void Update()
                {
                    delay++;
                    if(delay == totalDelay)
                    {
                        currentFrame++;
                        delay = 0;
                    }
                    
                    if (currentFrame == totalFrames)
                        currentFrame = 0;

                }

                public void Draw(SpriteBatch spriteBatch, Vector2 location)
                {
                     int currentX=209+ currentFrame*26;
                     int currentY = 122;
            //animated, source rectangle is different 
                    Rectangle sourceRectangle = new Rectangle( currentX, currentY , width, height );
            // non-moving, destination stays the same 
                    Rectangle destinationRectangle = new Rectangle((int)location.X, (int)location.Y, width, height );

                    spriteBatch.Begin();
                    spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
                    spriteBatch.End();
                }
        }
    
}

