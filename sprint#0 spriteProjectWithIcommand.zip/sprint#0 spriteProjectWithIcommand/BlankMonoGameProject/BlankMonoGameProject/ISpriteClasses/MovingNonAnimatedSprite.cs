﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;


namespace SpritesProject
{
    public class MovingNonAnimatedSprite: ISprites
    {
        public Texture2D Texture { get; set; }
       
        private int width = 16;
        private int height = 32;
        private int sourceX = 362;
        private int sourceY = 122;
        private int yPos = 200;
        private bool movingUp = true;
       
         
        


        public MovingNonAnimatedSprite(Texture2D texture)
        {
            Texture = texture;
             
        }

        public void Update()
        {


            if (movingUp)
            {
                yPos --;
                if (yPos == 0)
                    movingUp = false;
            }
            else
            {
                yPos ++;
                if (yPos == 360)
                    movingUp = true;
            }



        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            // moving but non animated: source doesn't change but destination changes 
            //Draw: one parameter is enough 
            Rectangle sourceRectangle = new Rectangle(sourceX, sourceY, width, height ); 
            //location Y needs change
            Rectangle destinationRectangle = new Rectangle((int)location.X, yPos, width, height);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}  

