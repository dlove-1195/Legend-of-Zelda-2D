﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlankMonoGameProject
{
    class Text
    {
        private SpriteFont font;
        private SpriteBatch spriteBatch;
        private Game1 game;
        public Text(Game1 game1) {
            game = game1;
            font = game.Content.Load<SpriteFont>("fonts/font");
            spriteBatch = game.spriteBatch;
           
        }
        public void Draw() {
            spriteBatch.Begin();
            spriteBatch.DrawString(font, "Credits", new Vector2(200, 300), Color.Black);
            spriteBatch.DrawString(font, "Program Made by: Xinyi Chen", new Vector2(200, 320), Color.Black);
            spriteBatch.DrawString(font, "Sprite from: http://www.mariouniverse.com/wp-content/img/sprites/nes/smb/mario.png", new Vector2(200, 340), Color.Black);
            spriteBatch.End();
        }
    }
}
