﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace BlankMonoGameProject
{
    class MovingNoneAnimatedSprite : ISprite
    {
        public Texture2D Texture { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }
        private int currentFrame;
        private int totalFrames;
        //Below are fields added for modifying positions.
        private int movement;
        private bool up= false;
        private int currentYLocation;
        private int delay;
        private int totalDelay;

        public MovingNoneAnimatedSprite(Texture2D texture)
        {
            Texture = texture;
            currentFrame = 0;
            totalFrames = 1;
            movement = 0;
            currentYLocation = 200;
            delay = 0;
            totalDelay = 3;
        }

        public void Update()
        {
            delay++;
            if (delay == totalDelay) { 
                currentFrame++;
            if (currentFrame == totalFrames)
                currentFrame = 0;
            currentYLocation = currentYLocation + movement;
            if (movement + currentYLocation >= 480) {
                movement = 0;
                up = true;
            }
            else if (movement + currentYLocation <= 0) {
                movement = 0;
                up = false;
            }
            if (up)
            {
                movement--;
            }
            else {
                movement++;
            }
                delay = 0;

            }
            
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            int width = 16;
            int height = 32;

            Rectangle sourceRectangle = new Rectangle(209,122, width, height);
            Rectangle destinationRectangle = new Rectangle((int)location.X, currentYLocation, width, height);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}