﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace BlankMonoGameProject
{
    class AnimatedSpriteNoneMoving : ISprite
    {
        public Texture2D Texture { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }
        private int currentFrame;
        private int totalFrames;
        private int delay;
        private int totalDelay;

        public AnimatedSpriteNoneMoving(Texture2D texture)
        {
            Texture = texture;
            currentFrame = 0;
            totalFrames = 4;
            delay = 0;
            totalDelay = 10;
        }

        public void Update()
        {
            delay++;
            if (delay == totalDelay) { 
            currentFrame++;
                if (currentFrame == totalFrames) { currentFrame = 0; }
                
                delay = 0;
            }
            
            
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            int width = 16;
            int height = 32;

            Rectangle sourceRectangle = new Rectangle(209 + (currentFrame*28),123, width, height);
            Rectangle destinationRectangle = new Rectangle((int)location.X, (int)location.Y, width, height);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
