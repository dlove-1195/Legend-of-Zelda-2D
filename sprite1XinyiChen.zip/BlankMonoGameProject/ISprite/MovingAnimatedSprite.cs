﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace BlankMonoGameProject
{
    class MovingAnimatedSprite : ISprite
    {
        public Texture2D Texture { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }
        private int currentFrame;
        private int totalFrames;
        //Below are fields added for modifying positions.
        private int movement;
        private bool left= false;
        private int currentXLocation;
        private int delay;
        private int totalDelay;
        private bool faceLeft = false;

        public MovingAnimatedSprite(Texture2D texture)
        {
            Texture = texture;
            currentFrame = 0;
            totalFrames = 4;
            movement = 0;
            currentXLocation = 350;
            delay = 0;
            totalDelay = 4;
        }

        public void Update()
        {
            delay++;
            if (delay == totalDelay) {
                if (faceLeft)
                {
                    currentFrame--;
                }
                else {
                    currentFrame++;
                }
                
            if (currentFrame == totalFrames || currentFrame == (totalFrames*-1))
                currentFrame = 0;
            currentXLocation = currentXLocation + movement;
            if (movement + currentXLocation >= 800) {
                movement = 0;
                currentFrame = 0;
                left = true;
                    faceLeft = true;
            }
            else if (movement + currentXLocation <= 0) {
                movement = 0;
                currentFrame = 0;
                left = false;
                    faceLeft = false;
            }

            if (left)
            {
                movement--;
            }
            else {
                movement++;
            }
                delay = 0;

            }
            
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            int width = 16;
            int height = 32;

            Rectangle sourceRectangle = new Rectangle(209 + currentFrame*28, 122, width, height);
            Rectangle destinationRectangle = new Rectangle(currentXLocation, (int)location.Y, width, height);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}