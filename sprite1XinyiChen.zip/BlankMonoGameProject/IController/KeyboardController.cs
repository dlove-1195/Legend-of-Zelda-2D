﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlankMonoGameProject
{
    public class KeyboardController : IController
    {
        public Game1 game { get; set; }
        public KeyboardController(Game1 game1)
        {
            game = game1;
        }
        public void Update() {
            KeyboardState keyboardstate = Keyboard.GetState();
            if (keyboardstate.IsKeyDown(Keys.D0))
            {
                game.Exit();
            }
            else if (keyboardstate.IsKeyDown(Keys.D1))
            {
                game.Isprite = new NoneMovingNoneAnimatedSprite(game.Isprite.Texture);
            }
            else if (keyboardstate.IsKeyDown(Keys.D2))
            {
                game.Isprite = new AnimatedSpriteNoneMoving(game.Isprite.Texture);
            }
            else if (keyboardstate.IsKeyDown(Keys.D3))
            {
                game.Isprite = new MovingNoneAnimatedSprite(game.Isprite.Texture);
            }
            else if (keyboardstate.IsKeyDown(Keys.D4)) {
                game.Isprite = new MovingAnimatedSprite(game.Isprite.Texture);
            }
        }
    }
}
