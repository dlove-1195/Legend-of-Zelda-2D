﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlankMonoGameProject
{
    class MouseController : IController
    {
        Game1 game1;
        MouseState mouse;
        public MouseController(Game1 game){
            game1 = game;
}
        public void Update() {
            mouse = Mouse.GetState();
            if (mouse.LeftButton == ButtonState.Pressed) { 
                if (mouse.Position.X <= 350 && mouse.Position.Y <= 200) {
                game1.Isprite = new NoneMovingNoneAnimatedSprite(game1.Isprite.Texture);
            }
                else if (mouse.Position.X > 350 && mouse.Position.Y <= 200)
            {
                game1.Isprite = new AnimatedSpriteNoneMoving(game1.Isprite.Texture);
            }
                else if (mouse.Position.X <= 350 && mouse.Position.Y > 200)
            {
                game1.Isprite = new MovingNoneAnimatedSprite(game1.Isprite.Texture);
            }
                else if (mouse.Position.X > 350 && mouse.Position.Y > 200)
            {
                game1.Isprite = new MovingAnimatedSprite(game1.Isprite.Texture);
            }
            }
            if (mouse.RightButton == ButtonState.Pressed) {
                game1.Exit();
                    }
            
        }
    }
}
